
/**
* @file
* @brief M�todo de interpolaci�n mediante Newton
* @author Sharyth Velasco Diaz <sharythvelasco@unicauca.edu.co>
* @copyright MIT License
*/

#ifndef NEWTON_H
#define NEWTON_H

#include <vector>
#include <cmath>
#include <string>
#include <sstream>

using std::vector;
using std::string;
using std::ostringstream;


namespace interpolacion {
	
	/**
	* @brief Interpolacion mediante diferencias divididas de newton
	*/
	class newton {
		
	public: 
		
		/**
		* @brief Interpolacion mediante diferencias divididas de newton
		* @param v_x Variable independiente
		* @param v_y Variable dependiente
		*/
		newton(vector<double> v_x, vector<double> v_y) : x(v_x), y(v_y) {
			b = calcular_coeficientes(x,y);
		}
		/**
		* @brief Retorna el polinomio interpolante usando todos los puntos
		* @return Texto del polinomio interpolante
		*/
		string polinomio() {
			ostringstream s;
			
			if(b.size() == 0) {
				return s.str();
			}
			//Comenzar con el coeficiente b[0]
			s << b[0];
			//Imprimir cada termino b[i] (x_int )
			for (size_t i=1; i<b.size(); i++) {
				s << (b[i] > 0? " + " : " - ") << fabs(b[i]) ;
				for(size_t j = 0; j < i; j++) {
					s << "(x " << (x[j]<0? " + ":" - ") << fabs(x[j]) << ")";
				}
			}
			return s.str();
		}
		
		/**
		* @brief Calcula los coeficientes del polinomio interpolante
		* @param x Variable independiente
		* @param y Variable dependiente
		* @return Vector de coeficientes
		*/
		static vector<double> calcular_coeficientes (vector<double> x, vector<double> y) {
			
			vector<double> coeficientes;
			
			//Verificar que existan datos
			//Y que el tama�o de x sea igual al tama�o de y
			if(x.size() == 0 || x.size() != y.size()) {
				return coeficientes;
			}
			
			size_t n = x.size();
			
			//Reservar espacio para n filas
			vector<vector<double>> F(n);
			//Inicializar las filas
			for(size_t i = 0; i<n; i++) {
				F[i].resize(n - i);
			}
			//Llenar la primera columna
			for(size_t i = 0; i < n; i++) {
				F[i][0] = y[i];
			}
			//Llenar las dem�s columnas
			
			for(size_t j = 1; j < n; j++) {
				for (size_t i = 0; i < n-j; i++) {
					F[i][j] = (F[i+1][j-1] - F[i][j-1])/(x[i+j] - x[i]);
				}
			}
			//Obtener la primera fila de la matriz
			coeficientes = F[0];
			//Retornar los coeficientes
			return coeficientes;
		}
		
		/**
		* @brief Calcula el valor del polinomio interpolante en x_int
		* @param x_int Valor de x
		* @return Valo del polinomio interpolante evaluado en x_int
		*/
		double interpolar(double x_int) {
			
			double y_int = NAN;
			
			//Validar si existe coeficientes
			if(b.size() == 0) {
				return y_int;
			}
			
			if(x_int < x[0] || x_int > x[x.size() - 1]) {
				return NAN;
			}
			//POST: Existe al menos un coeficiente
			y_int = b[0];
			
			
			for (size_t i=1; i<b.size(); i++) {
				
				double prod = 1.0f;
				
				for(size_t j = 0; j < i; j++) {
					prod *=(x_int - x[j]);
				}
				
				y_int += b[i]*prod;
			}
			
			return y_int;
		}
	private:
			
			vector<double> x; /*!< Variable independiete */
			vector<double> y; /*!< Variable dependiete */
			vector<double> b; /*!< Coeficientes del polinomio interpolante */
			
	};
};

#endif
