
/**
* @file
* @brief Interpolacion
* @author Sharyth Velasco Diaz <sharythvelasco@unicauca.edu.co>
* @copyright MIT License
*/

#include<iostream>
#include "newton.h"
#include <vector>
#include "lagrange.h"
#include "spline3.h"
using namespace std;
using std::cout;
using std::endl;
using std::vector;
using interpolacion::lagrange;
using interpolacion::newton;
using interpolacion::spline3;

/** @brief Caso 1 Newton -  diapositivas */
void caso_1_newton();

/** @brief Caso 1 Lagrange -  (Mismo datos de caso_1_newton) */
void caso_1_lagrange();

/** @brief Caso 1 - Logaritmo Neperiano*/
void caso_1_lineal();

/** @brief Caso Sodio */
void caso_1_sodio();

/** @brief Caso Error de Interpolacion */
void caso_error_interpolacion();

/** @brief Caso Trazadores Cubicos - diapositivas */
void caso_1_spline3();

/** @brief Caso Error interpolacion grado 3 - diapositivas */
void caso_error_interpolacion2();

int main (int argc, char *argv[]) {
	
	char opc2 = 'n';
	do{
		system("cls");
		cout << "INTERPOLACIONES: " << endl;
		cout << " " << endl;
		cout << "CASO: Las diferentes contracciones de un resorte, a causa de las cargas aplicadas" << endl;
		cout << " " << endl;
		cout << "1. Metodo de Newton" << endl;
		cout << "2. Metodo de Lagrange" << endl;
		cout << "3. Metodo de spline3" << endl;
		cout << "4. Error Interpolacion grado 2" << endl;
		cout << "5. Error Interpolacion grado 3" << endl;
		cout << "6. Metodo logaritmo neperiano" << endl;
		cout << "7. Metodo Sodio" << endl;
		cout << " " << endl;
		cout << "Seleccione una de las anteriores opciones: ";
		int opc1;
		cin >> opc1;
		switch(opc1){
		case 1:
			caso_1_newton();
			break;
		case 2:
			caso_1_lagrange();
			break;
		case 3:
			caso_1_spline3();
			break;
		case 4:
			caso_error_interpolacion();
			break;
		case 5:
			caso_error_interpolacion2();
			break;
		case 6:
			caso_1_lineal();
			break;
		case 7:
			caso_1_sodio();
			break;
		default:
			cout << "Recuerde seleccionar una de las opciones mostradas..." << endl;
			system("pause");
			system("cls");
			break;
		}
		cout << "Volver al menu principal (s/n): ";
		cin >> opc2;
	}while(opc2 == 's');
}

void caso_1_newton() {
	cout << "Interpolacion usando diferencias divididas de Newton" << endl;
	
	vector<double> x {5.0f, 10.0f, 15.0f, 20.0f, 25.0f};
	vector<double> y {49.0f, 105.0f, 172.0f, 253.0f, 352.0f};
	
	//Crear una instancia del metodo de Newton
	newton n(x,y);
	
	//Interpolar un valor de x
	
	double x_int = 16.5f;
	
	double y_int = n.interpolar(x_int);
	
	cout<< "f(" << x_int << ") = " << y_int << endl; 
	cout << "Polinomio interpolante: " << endl << n.polinomio() << endl;
}

void caso_1_lagrange() {
	cout << "Interpolacion usando Lagrange" << endl;

	vector<double> x {5.0f, 10.0f, 15.0f, 20.0f, 25.0f};
	vector<double> y {49.0f, 105.0f, 172.0f, 253.0f, 352.0f};
	
	//Crear una instancia del metodo de Lagrange
	lagrange l(x,y);
	
	//Interpolar un valor de x
	
	double x_int = 16.5f;
	
	double y_int = l.interpolar(x_int);
	
	cout<< "f(" << x_int << ") = " << y_int << endl; 
	cout << "Polinomio interpolante: " << endl << l.polinomio() << endl;
}
void caso_1_lineal() {
	cout << "Interpolacion logaritmo neperiano." << endl;
	
	vector<double> x {5.0f, 10.0f, 15.0f, 20.0f, 25.0f};
	vector<double> y {49.0f, 105.0f, 172.0f, 253.0f, 352.0f};
	
	//Crear una instancia del metodo de Newton
	newton n(x,y);
	//Crear una instancia del metodo de Lagrange
	lagrange l(x,y);
	//Interpolar un valor de x
	double x_int = 16.5f;
	
	double y_int = n.interpolar(x_int);
	
	cout<< "Usando Newton: f(" << x_int << ") = " << y_int << endl; 
	//cout << "Polinomio interpolante: " << n.polinomio() << endl;
	
	y_int = l.interpolar(x_int);
	cout<< "Usando Lagrange: f(" << x_int << ") = " << y_int << endl; 
}
void caso_1_sodio(){
	cout << "Interpolacion Sodio" << endl;
	
	double x_int = 16.5f;
	
	vector<double> x {5.0f, 10.0f, 15.0f, 20.0f, 25.0f};
	vector<double> y {49.0f, 105.0f, 172.0f, 253.0f, 352.0f};
	
	//Crear una instancia del metodo de Newton
	newton n(x,y);
	//Crear una instancia del metodo de Lagrange
	lagrange l(x,y);
	//Interpolar un valor de x
	
	double y_int = n.interpolar(x_int);
	
	cout<< "Usando Newton: f(" << x_int << ") = " << y_int << endl; 
	cout << "Polinomio interpolante: " << n.polinomio() << endl;
	
	y_int = l.interpolar(x_int);
	cout<< "Usando Lagrange: f(" << x_int << ") = " << y_int << endl; 
	cout << "Polinomio interpolante: " << l.polinomio() << endl;
}
	
	void caso_error_interpolacion(){
		cout << "Caso: Error de interpolacion" << endl;
		
		double x_int = 16.5f;
		cout << "Valor a interpolar: " << x_int << endl;
		
		int grado = 2;
		
		cout << "Grado: " << grado << endl;
		vector<double> x {5.0f, 10.0f, 15.0f, 20.0f, 25.0f};
		vector<double> y {49.0f, 105.0f, 172.0f, 253.0f, 352.0f};
		
		//Crear una instancia del metodo de Lagrange
		lagrange l(x,y);
		//Interpolar un valor de x
		
		double y_int = l.interpolar(x_int,grado);
		
		cout<< "Usando Lagrange: f(" << x_int << ") = " << y_int << endl; 
	}
		
		void caso_1_spline3() {
			cout << "Interpolacion usando Trazadores Cubicos" << endl;
			
			vector<double> x {5.0f, 10.0f, 15.0f, 20.0f, 25.0f};
			vector<double> y {49.0f, 105.0f, 172.0f, 253.0f, 352.0f};
			//Crear una instancia del metodo de Newton
			spline3 s(x,y);
			//Interpolar un valor de x
			
			double x_int = 16.5f;
			
			double y_int = s.interpolar(x_int);
			
			cout<< "f(" << x_int << ") = " << y_int << endl; 
			
		}
		void caso_error_interpolacion2(){
			cout << "Caso: Error de interpolacion" << endl;
			
			double x_int = 16.5f;
			cout << "Valor a interpolar: " << x_int << endl;
			
			int grado = 3;
			
			cout << "Grado: " << grado << endl;
			vector<double> x {5.0f, 10.0f, 15.0f, 20.0f, 25.0f};
			vector<double> y {49.0f, 105.0f, 172.0f, 253.0f, 352.0f};
			
			//Crear una instancia del metodo de Lagrange
			lagrange l(x,y);
			newton n(x,y);
			//Interpolar un valor de x
			
			double y_int = l.interpolar(x_int,grado);
			//double y_int = n.interpolar(x_int,grado);
			
			cout<< "Usando Newton: f(" << x_int << ") = " << y_int << endl; 
			cout<< "Usando Lagrange: f(" << x_int << ") = " << y_int << endl; 
		}
		
