/**
* @file
* @brief M�todo de interpolaci�n mediante Lagrange
* @author Sharyth Velasco Diaz <sharythvelasco@unicauca.edu.co>
* @copyright MIT License
*/

#ifndef LAGRANGE_H
#define LAGRANGE_H

#include <vector>
#include <cmath>
#include <string>
#include <sstream>

using std::vector;
using std::string;
using std::ostringstream;
using std::cout;
using std::endl;

namespace interpolacion {
	
	/**
	* @brief Metodo de interpolacion de Lagrange
	*/
	class lagrange {
	public:
		/**
		* @brief Crea una instancia de Lagrange
		* @param v_x Variable independiente
		* @param v_y Variable dependiente
		* @note Si se especifica grado 0, se usan todos los datos para interpolar.
		*/
		lagrange(vector<double> v_x, vector<double> v_y) : x(v_x), y(v_y) {
		}
		
		
		/**
		* @brief Calcula el valor interpolado de y dado x
		* @param x_int Valor de x
		* @return Valor interpolado
		*/
		double interpolar(double x_int) {
			double sum = 0.0f;
			
			if (!x.size() || x.size() != y.size()) {
				return NAN;
			}
			if (x_int < x[0] || x_int > x[x.size() - 1]) {
				return NAN;
			}
			size_t n = x.size();
			for (size_t j = 0; j < n; j++) {
				//Calcular la productoria Lj
				double Lj = 1.0f;
				
				for (size_t k = 0; k < n; k++) {
					if (k != j) {
						Lj *= (x_int - x[k]) / (x[j] - x[k]);
					}
				}
				sum += y[j] * Lj;
			}
			
			return sum;
		}
		/**
		* @brief Interpola usando un polinomio de grado especificado
		* @param x_int Valor a interpolar
		* @param grado Grado del polinomio interpolante
		* @return Valor interpolado
		*/
		double interpolar(double x_int, unsigned int grado) {
			
			size_t cantidad; /* !< Cantidad de puntos a tomar*/
			size_t inicio; /* !< Inicio de un determinado subvector*/
			size_t fin; /* !< Final de un determinado subvector*/
			
			cout << "Tamanio de x: " << x.size() << endl;
			size_t i = 0; /* Indice del siguiente dato de x_int*/
			
			// Comprobaci�n de validez del grado
			if (grado >= x.size() || grado < 0) {
				return NAN;
			}
			
			// Si el grado es cero o igual al tama�o de los datos menos uno, se interpola con todos los datos disponibles
			if (grado == 0 || grado == x.size() - 1) {
				return interpolar(x_int);
			}
			
			// Encontrar el intervalo en el que x_int se encuentra
			while (i < x.size() && x[i] < x_int) {
				i++;
			}
			
			// Si el grado es impar
			if (grado % 2 == 1) {
				
				double y_int; /* !< Valor interpolado*/
				
				cantidad = grado + 1;
				
				inicio = i - (cantidad / 2);
				
				fin = inicio + grado;
				
				// Comprobar si x_int est� dentro del intervalo de interpolaci�n
				if (x[inicio] > x_int || x[fin] < x_int) {
					return NAN;
				}
				
				// Seleccionar los puntos del intervalo
				vector<double> x_sub = hallar_vector(inicio, fin, x); /* !< Variable independiente alternativa*/
				vector<double> y_sub = hallar_vector(inicio, fin, y); /* !< Variable dependiente alternativa*/
				
				// Crear una instancia de Lagrange con los puntos seleccionados y realizar la interpolaci�n
				lagrange l(x_sub, y_sub);
				y_int = l.interpolar(x_int);
				return y_int;
			}
			// Si el grado es par
			else {
				
				vector<double> x_sub; /* !< Variable independiente alternativa*/
				vector<double> y_sub; /* !< Variable dependiente alternativo*/
				
				vector<double> x_sub_coeficientes; /* !< Vector de x_sub con el valor adicional para el m�todo de Newton */
				vector<double> y_sub_coeficientes; /* !< Vector de y_sub con el valor adicional para el m�todo de Newton */
				
				vector<double> coeficientes; /* !< Vector de coeficientes retornado por Newton para el c�lculo del error de los subintervalos*/ 
				
				double y_int_sup; /* !< Valor interpolado para el primer subintervalo*/
				double y_int_inf; /* !< Valor interpolado para el segundo subintervalo*/
				
				double R; /* !< �ltimo coeficientes del vector de coeficientes */
				
				double error_sup; /* !< Error para el primer subintervalo*/
				double error_inf; /* !< Error para el segundo subintervalo*/
				
				// Calcular el intervalo superior
				inicio = i - ((grado / 2) + 1);
				fin = inicio + grado;
				
				// Si x_int est� dentro del intervalo superior
				if (x[inicio] < x_int && x[fin] > x_int) {
					
					// Seleccionar los puntos del intervalo superior
					x_sub = hallar_vector(inicio, fin, x);
					y_sub = hallar_vector(inicio, fin, y);
					
					// Seleccionar los puntos adicionales necesarios para el c�lculo de los coeficientes
					x_sub_coeficientes = hallar_vector(inicio, fin + 1, x);
					y_sub_coeficientes = hallar_vector(inicio, fin + 1, y);
					
					// Calcular los coeficientes del polinomio interpolante mediante el m�todo de Newton
					coeficientes = newton::calcular_coeficientes(x_sub_coeficientes, y_sub_coeficientes);
					R = coeficientes.back();
					
					// Crear una instancia de Lagrange con los puntos del intervalo superior y realizar la interpolaci�n
					lagrange l(x_sub, y_sub);
					y_int_sup = l.interpolar(x_int);
					// Calcular el error de interpolaci�n para el intervalo superior
					error_sup = calcular_error(R, x_int, x_sub);
				}
				else {
					y_int_sup = NAN;
				}
				
				// Limpiar los vectores temporales para usarlos en el siguiente intervalo
				x_sub.clear();
				y_sub.clear();
				
				x_sub_coeficientes.clear();
				y_sub_coeficientes.clear();
				
				coeficientes.clear();
				
				// Calcular el intervalo inferior
				inicio = i - (grado / 2);
				fin = inicio + grado + 1;
				// Si x_int est� dentro del intervalo inferior
				if (x[inicio] < x_int && x[fin] > x_int) {
					
					// Seleccionar los puntos del intervalo inferior
					x_sub = hallar_vector(inicio, fin, x);
					y_sub = hallar_vector(inicio, fin, y);
					
					// Seleccionar los puntos adicionales necesarios para el c�lculo de los coeficientes
					x_sub_coeficientes = hallar_vector(inicio - 1, fin, x);
					y_sub_coeficientes = hallar_vector(inicio - 1, fin, y);
					
					// Calcular los coeficientes del polinomio interpolante mediante el m�todo de Newton
					coeficientes = newton::calcular_coeficientes(x_sub_coeficientes, y_sub_coeficientes);
					R = coeficientes.back();
					
					// Crear una instancia de Lagrange con los puntos del intervalo inferior y realizar la interpolaci�n
					lagrange l(x_sub, y_sub);
					y_int_inf = l.interpolar(x_int);
					// Calcular el error de interpolaci�n para el intervalo inferior
					error_inf = calcular_error(R, x_int, x_sub);
				}
				else {
					y_int_inf = NAN;
				}
				
				// Si no se pudo realizar la interpolaci�n en el intervalo superior, se retorna la interpolaci�n del intervalo inferior
				if (y_int_sup == NAN) {
					return y_int_inf;
				}
				// Si no se pudo realizar la interpolaci�n en el intervalo inferior, se retorna la interpolaci�n del intervalo superior
				if (y_int_inf == NAN) {
					return y_int_sup;
				}
				
				cout << "Error superior: " << error_sup << endl;
				cout << "Error inferior: " << error_inf << endl;
				
				// Seleccionar la interpolaci�n con menor error absoluto
				if (fabs(error_sup) < fabs(error_inf)) {
					return y_int_sup;
				}
				else {
					return y_int_inf;
				}
			}
			return NAN;
		}
		
		
		/**
		* @brief Construye el polinomio interpolante
		* @return Texto del polinomio interpolante
		*/
		string polinomio() {
			
			ostringstream s;
			
			size_t n = x.size();
			for (size_t j = 0; j < n; j++) {
				ostringstream s_num;
				ostringstream s_denom;
				
				for (size_t k = 0; k < n; k++) {
					if (k != j) {
						s_num << "(x" << (x[k] > 0 ? " - " : " + ") << fabs(x[k]) << ")";
						s_denom
							<< "(" << (x[j] < 0 ? " - " : " + ") << fabs(x[k]) << ")";
					}
				}
				
				s << (y[j] < 0 ? " - " : (y[j] > 0 && j > 0 ? " + " : "")) << fabs(y[j]) << " * (" << s_num.str() << ")" << "/ (" << s_denom.str() << ")";
			}
			
			return s.str();
		}
	private:
			vector<double> x; /* !< Variable independiente*/
			vector<double> y; /* !< Variable dependiente*/
			
			/**
			* @brief Calcula el error del polinomio interpolante en un punto dado
			* @param coef Coeficientes del polinomio interpolante
			* @param x_int Valor de x donde calcular el error
			* @param x_sub Puntos del subintervalo
			* @return Valor del error
			*/
			double calcular_error(double R, double x_int, vector<double> x_sub) {
				double error = 0.0;
				double prod = 1.0;
				
				for (size_t i = 0; i < x_sub.size(); i++) {
					prod *= (x_int - x_sub[i]);
				}
				error = R * prod;
				
				return error;
			}
			
			/**
			* @brief Crea un subvector a partir de otro con sus puntos iniciales y finales
			* @param inicio Punto de partida del nuevo vector
			* @param fin Punto final del nuevo vector
			* @param vector_origen Vector original del cual se crear� el requerido
			* @return vector Subvector creado
			*/
			
			vector<double> hallar_vector(size_t inicio, size_t fin, vector<double> vector_origen) {
				vector<double> vector;
				for (size_t i = inicio; i <= fin; ++i) {
					vector.push_back(vector_origen[i]);
				}
				return vector;
			}
			
	};
};

#endif
