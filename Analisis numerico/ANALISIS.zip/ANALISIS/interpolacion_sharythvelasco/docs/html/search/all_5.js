var searchData=
[
  ['newton_0',['newton',['../classinterpolacion_1_1newton.html',1,'interpolacion::newton'],['../classinterpolacion_1_1newton.html#a942573e3c89080ee06357705b78bdce7',1,'interpolacion::newton::newton()']]],
  ['newton_2eh_1',['newton.h',['../newton_8h.html',1,'']]]
];
