var searchData=
[
  ['newton_2eh_0',['newton.h',['../newton_8h.html',1,'']]]
];
