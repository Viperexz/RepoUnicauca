var searchData=
[
  ['newton_0',['newton',['../classinterpolacion_1_1newton.html#a942573e3c89080ee06357705b78bdce7',1,'interpolacion::newton']]]
];
