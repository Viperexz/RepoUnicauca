var searchData=
[
  ['newton_0',['newton',['../classinterpolacion_1_1newton.html',1,'interpolacion']]]
];
