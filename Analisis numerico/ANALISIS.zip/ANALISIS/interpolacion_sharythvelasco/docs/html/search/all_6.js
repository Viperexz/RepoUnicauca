var searchData=
[
  ['pendientes_0',['Lista de tareas pendientes',['../todo.html',1,'']]],
  ['polinomio_1',['Polinomio',['../classinterpolacion_1_1newton.html#a2101a1304e05ca0f1a687e0c6cce1e59',1,'interpolacion::newton']]],
  ['polinomio_2',['polinomio',['../classinterpolacion_1_1lagrange.html#adf21fa211b1e4caeda5e05b1d4fb2456',1,'interpolacion::lagrange']]]
];
