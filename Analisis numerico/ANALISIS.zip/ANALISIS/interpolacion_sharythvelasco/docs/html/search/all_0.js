var searchData=
[
  ['calcular_5fcoeficientes_0',['calcular_coeficientes',['../classinterpolacion_1_1newton.html#a3a9a3348c4cdc2c465a0285ea8e3f7e1',1,'interpolacion::newton']]],
  ['caso_5f1_5flagrange_1',['caso_1_Lagrange',['../main_8cpp.html#a2f1a2b40417e1974360c42ccc263dae9',1,'main.cpp']]],
  ['caso_5f1_5flineal_2',['caso_1_lineal',['../main_8cpp.html#acb7b48c8466a625f1fc2a348cf099a78',1,'main.cpp']]],
  ['caso_5f1_5fnewton_3',['caso_1_newton',['../main_8cpp.html#abd41b6ebd4316c668351571c3857c4fd',1,'main.cpp']]],
  ['caso_5f1_5fsodio_4',['caso_1_sodio',['../main_8cpp.html#a50513d28bf4f5542347f4d84724d3241',1,'main.cpp']]]
];
