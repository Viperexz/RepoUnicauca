var searchData=
[
  ['lagrange_0',['lagrange',['../classinterpolacion_1_1lagrange.html',1,'interpolacion']]]
];
