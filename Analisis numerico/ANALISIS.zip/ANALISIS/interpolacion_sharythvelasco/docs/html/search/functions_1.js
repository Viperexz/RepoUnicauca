var searchData=
[
  ['interpolar_0',['interpolar',['../classinterpolacion_1_1newton.html#aa88407a386efc88886a70128b9bf1450',1,'interpolacion::newton::interpolar()'],['../classinterpolacion_1_1lagrange.html#a5afb2961447ba74861179235648ef6f1',1,'interpolacion::lagrange::interpolar(double x_int)'],['../classinterpolacion_1_1lagrange.html#aecb9764a2a1dffe2a7d24885f389f909',1,'interpolacion::lagrange::interpolar(double x_int, unsigned int grado)']]]
];
