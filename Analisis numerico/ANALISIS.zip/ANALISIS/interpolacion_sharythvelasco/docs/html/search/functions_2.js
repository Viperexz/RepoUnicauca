var searchData=
[
  ['lagrange_0',['lagrange',['../classinterpolacion_1_1lagrange.html#aa1baad2177bf230c599f04f96bb5ae96',1,'interpolacion::lagrange']]]
];
