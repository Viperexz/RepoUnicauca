var indexSectionsWithContent =
{
  0: "cdilmnpt",
  1: "ln",
  2: "i",
  3: "lmn",
  4: "cilmnp",
  5: "dlpt"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "pages"
};

var indexSectionLabels =
{
  0: "Todos",
  1: "Clases",
  2: "Espacios de nombres",
  3: "Archivos",
  4: "Funciones",
  5: "Páginas"
};

