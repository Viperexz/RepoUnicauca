var searchData=
[
  ['lagrange_0',['lagrange',['../classinterpolacion_1_1lagrange.html',1,'interpolacion::lagrange'],['../classinterpolacion_1_1lagrange.html#aa1baad2177bf230c599f04f96bb5ae96',1,'interpolacion::lagrange::lagrange()']]],
  ['lagrange_2eh_1',['lagrange.h',['../lagrange_8h.html',1,'']]],
  ['lista_20de_20tareas_20pendientes_2',['Lista de tareas pendientes',['../todo.html',1,'']]]
];
