var searchData=
[
  ['tareas_20pendientes_0',['Lista de tareas pendientes',['../todo.html',1,'']]]
];
