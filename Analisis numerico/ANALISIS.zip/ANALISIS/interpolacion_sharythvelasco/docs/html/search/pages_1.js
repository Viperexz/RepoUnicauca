var searchData=
[
  ['lista_20de_20tareas_20pendientes_0',['Lista de tareas pendientes',['../todo.html',1,'']]]
];
