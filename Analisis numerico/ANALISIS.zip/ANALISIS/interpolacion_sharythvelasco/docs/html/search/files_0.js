var searchData=
[
  ['lagrange_2eh_0',['lagrange.h',['../lagrange_8h.html',1,'']]]
];
