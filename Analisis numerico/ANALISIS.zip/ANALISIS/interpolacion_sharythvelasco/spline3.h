/**
* @file
* @brief Interpolacion mediante Trazadores (splines) Cubicos (de orden 3)
* @author Sharyth Velasco D�az <sharythvelasco@unicauca.edu.co>
* @license MIT License
*/

#ifndef SPLINE3_H
#define SPLINE3_H

#include <vector>
#include <cmath>
#include "gauss.h"

using std::vector;
namespace interpolacion {
	/**
	* @brief Interpolacion mediante trazadores cubicos
	*/ 
	class spline3 {
		
	public:
		/**
		* @brief Construye una instancia de spline3
		* @param v_x Variable independiente
		* @param v_y Variable dependiente
		*/
		spline3 (vector<double> v_x, vector<double> v_y): x(v_x), y(v_y) {
			f2 = calcular();
			
		}
		
		/**
		* @brief Calcula el valor interpolado de x_int
		* @param x_int Valor a interpolar
		* @return Valor interpolado
		*/
		double interpolar(double x_int) {
			
			if (x.size() == 0 || x.size() != y.size()) {
				return NAN;
			}
			
			if (x_int < x[0] || x_int > x[x.size() -1 ]) {
				return NAN;
			}
			
			size_t i = 0;
			
			// Encontrar el intervalo en el que x_int se encuentra
			while (i < x.size() && x[i] < x_int) {
				i++;
			}
			
			double t1 = 0.0f;
			double t2 = 0.0f;
			double t3 = 0.0f;
			double t4 = 0.0f;
			
			if (i-1 != 0) {
				t1 = (f2[i-1] / 6.0f*(x[i]-x[i-1]))*pow(x[i] - x_int,3.0f);
			}
			
			t2 = (f2[i] / 6.0f*(x[i]-x[i-1]))*pow(x_int - x[i-1] ,3.0f);
			t3 = ((y[i-1]/(x[i] - x[i-1]))-((f2[i-1]/6.0f)*(x[i]-x[i-1])))*(x[i] - x_int);
			t4 = ((y[i]/(x[i] - x[i-1]))-((f2[i]/6.0f)*(x[i]-x[i-1])))*(x_int - x[i-1]);
			return t1 + t2 + t3 + t4;
		}
		
		
	private:
			vector<double> x; /*!< Variable independiente*/
			vector<double> y; /*!< Variable dependiente*/
			vector<double> f2; /*!< Arreglo de segundas derivadas*/
			
			/**
			* @brief Calcula las segundas derivadas de los puntos interiores
			* @return Vector de segundas derivadas
			* @note Las segundas derivadas en los extremos son 0.
			*/
			vector<double> calcular() {
				
				vector<double> resultado(x.size());
				
				//Crear el sistema de ecuaciones
				size_t n = x.size();
				//Se requiren por lo menos dos puntos intermedios
				//Para crear un sistema de ecuaciones de minimo 2x2
				if(n<4) {
					return resultado;
				}
				
				//Cantidad de filas es la cantidad de puntos intermedios (n-2)
				vector <vector<double>> m(n-2);
				
				for(size_t i = 0; i<m.size(); i++) {
					m[i].resize(n-1); //Cada fila incluye el t�rmino independiente
					int k = i+1;
					for (size_t j = 0; j <m[i].size() - 1; j++) {
						double t1 = 0.0f;
						//Si i!= 0, calcular el primer termino
						if (i!= 0) {
							t1 = x[k] - x[k-1];
						}
						//Calcular el segundo termino
						
						double t2 = 2.0f * (x[k+1] - x[k-1]);
						
						double t3 = 0.0f;
						
						//Si i!= m.size() - 1, calcular el tercer termino
						if (i!= m.size() - 1) {
							t3 = x[k+1] - x[k];
						}
						
						//Sumar los t�rminos
						m[i][j] = 0.0f;
						
						if (i!=0) {
							m[i][i - 1] = t1;
						}
						
						if (i==j) {
							m[i][j] = t2;
						}
	
						if (i!= m.size() - 1) {
							m[i][i+1] = t3;
						}
					}
					//Colocar el termino independiente
					double c1 =  (6.0f)*(y[k+1] - y[k])/ (x[k+1] - x[k]);
					double c2 = (6.0f)*(y[k-1] - y[k]) / (x[k] - x[k-1]);
					m[i][m.size()] = c1 + c2;
				}

				// Imprimir la matriz m
				std::cout << "Matriz m:" << std::endl;
				for (size_t i = 0; i < m.size(); ++i) {
					for (size_t j = 0; j < m[i].size(); ++j) {
						std::cout << m[i][j] << "\t";
					}
					std::cout << std::endl;
				}
				vector <double> sol = gauss(m);
			
				sol.insert(sol.begin(), 0.0);
				sol.push_back(0.0);
				
				// Imprimir el vector f2
				std::cout << "Vector sol: [";
				for (size_t i = 0; i < sol.size(); ++i) {
					std::cout << sol[i];
					if (i != sol.size() - 1) {
						std::cout << ", ";
					}
				}
				std::cout << "]" << std::endl;
				
				return sol;
			}
	};
};

#endif
