#include<iostream>
#include<string>
#include "casos.h"


using std:: cout;
using std:: endl;
using std:: string;


int main () {

	caso_1();
	//caso_2();
	//caso_3();
	//caso_4();
	//caso_5();
	//caso_6();
	
	return 0;
}

