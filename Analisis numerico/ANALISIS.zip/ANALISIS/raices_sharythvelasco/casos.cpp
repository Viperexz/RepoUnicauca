#include "casos.h"
#include <iostream>

#include "biseccion.h"
#include "expression.h"
#include "raices.h"
#include "newton_raphson.h"
#include "regla_falsa.h"
#include "casos.h"
#include "secante.h"
#include "newton_raphson_g.h"
#include "muller.h"

using std:: cout;
using std:: endl;

using raices::muller;
using raices:: newton_raphson_g;
using raices:: secante;
using raices:: newton_raphson;
using raices:: biseccion;
using raices:: regla_falsa;
using raices:: aproximacion;
using raices:: solucion; 
using raices:: imprimir_solucion;

#define TOL 1e-5f

void caso_1(){

	string str_func = "e^~(x) - ln(x)";
	double xInf= 1.0f;//extremo inferior
	double xSup = 1.5f;//extremo superior del intervalo
	
	
	double tolerancia = TOL;//error relativo porcentual
	int n = 100;
	
	
	cout<<"Funcion: " <<str_func << endl;
	cout<< "Intervalo: " << xInf << "....." << xSup << endl;
	
	cout <<"Solucion por el metodo biseccion" << endl;
	//crear la instancia del metodo
	biseccion b(str_func);
	//encontrar la raiz en el intervalo dado
	solucion sol = b.encontrar(xInf, xSup, tolerancia, n);
	//imprimir la solucion
	imprimir_solucion(sol);
	cout <<"-------------------------------------------------------------------" << endl;
	
	cout <<"Solucion por el metodo de regla falsa" << endl;
	//crear la instancia del metodo
	regla_falsa rf(str_func);
	//encontrar la raiz en el intervalo dado
	solucion solRf = b.encontrar(xInf, xSup, tolerancia, n);
	//imprimir la solucion
	imprimir_solucion(solRf);
	cout <<"-------------------------------------------------------------------" << endl;
	
	cout <<"Solucion por el metodo de Newton Raphson" << endl;
	//crear la instancia del metodo
	double p0 =xInf;
	
	string str_dfunc = "~e^~(x) - (1/x)";
	//crear la instancia del metodo
	newton_raphson nr(str_func, str_dfunc);
	
	solucion solNr = nr.encontrar(p0, tolerancia, n);
	
	imprimir_solucion(solNr);
	cout <<"-------------------------------------------------------------------" << endl;
	
	
	double x0= xInf;//extremo inferior
	double x1 = xSup;//extremo superior del intervalo
	
	cout<< "Intervalo: " << x0 << "....." << x1 << endl;
	
	cout <<"Solucion por el metodo secante" << endl;
	//crear la instancia del metodo
	secante sec(str_func);
	//encontrar la raiz en el intervalo dado
	solucion solSec = sec.encontrar(x0, x1, tolerancia, n);
	//imprimir la solucion
	imprimir_solucion(solSec);
	
	cout <<"-------------------------------------------------------------------" << endl;
	
	x0= 0.5f;//extremo inferior
	x1 = 2.0f;//extremo superior del intervalo
	double x2 = 4.0f;
		
	
	cout <<"Solucion por el metodo de Muller" << endl;
	
	cout <<"Puntos de la parabola: " 
		<< x0 << " , "
		<<x1 << ", " << x2 << endl;
		
	//crear la instancia del metodo
	muller mul(str_func);
	//encontrar la raiz en el intervalo dado
	solucion solMuller = mul.encontrar(x0, x1, x2, tolerancia, n);
	//imprimir la solucion
	imprimir_solucion(solMuller);
	
	cout <<"-------------------------------------------------------------------" << endl;
	
}

	void caso_2(){
		
		string str_func = "x^3 + 4*x^2 - 10";
		double xInf= -0.5f;//extremo inferior
		double xSup = 0.5f;//extremo superior del intervalo
		
		
		double tolerancia = 1.0f;//error relativo porcentual
		int n = 100;
		
		
		cout<<"Funcion: " <<str_func << endl;
		cout<< "Intervalo: " << xInf << "....." << xSup << endl;
		
		cout <<"Solucion por el metodo biseccion" << endl;
		//crear la instancia del metodo
		biseccion b(str_func);
		//encontrar la raiz en el intervalo dado
		solucion sol = b.encontrar(xInf, xSup, tolerancia, n);
		//imprimir la solucion
		imprimir_solucion(sol);
		cout <<"-------------------------------------------------------------------" << endl;
		
		cout <<"Solucion por el metodo de regla falsa" << endl;
		//crear la instancia del metodo
		regla_falsa rf(str_func);
		//encontrar la raiz en el intervalo dado
		solucion solRf = b.encontrar(xInf, xSup, tolerancia, n);
		//imprimir la solucion
		imprimir_solucion(solRf);
		cout <<"-------------------------------------------------------------------" << endl;
		
		cout <<"Solucion por el metodo de Newton Raphson" << endl;
		//crear la instancia del metodo
		double p0 =xInf;
		
		string str_dfunc = "3*x^2 + 8*x";
		//crear la instancia del metodo
		newton_raphson nr(str_func, str_dfunc);
		
		solucion solNr = nr.encontrar(p0, tolerancia, n);
		
		imprimir_solucion(solNr);
		cout <<"-------------------------------------------------------------------" << endl;
		
		
		double x0= xInf;//extremo inferior
		double x1 = xSup;//extremo superior del intervalo
		
		cout<< "Intervalo: " << x0 << "....." << x1 << endl;
		
		cout <<"Solucion por el metodo secante" << endl;
		//crear la instancia del metodo
		secante sec(str_func);
		//encontrar la raiz en el intervalo dado
		solucion solSec = sec.encontrar(x0, x1, tolerancia, n);
		//imprimir la solucion
		imprimir_solucion(solSec);
		
		cout <<"-------------------------------------------------------------------" << endl;
		
	}
	
	void caso_3() {			
			string str_func = "(e^(~x))+ x^2 -2";
			double xInf= -1.0f;//extremo inferior
			double xSup = 0.0f;//extremo superior del intervalo
			
			
			double tolerancia = 1.0f;//error relativo porcentual
			int n = 100;
			
			
			cout<<"Funcion: " <<str_func << endl;
			cout<< "Intervalo: " << xInf << "....." << xSup << endl;
			
			cout <<"Solucion por el metodo biseccion" << endl;
			//crear la instancia del metodo
			biseccion b(str_func);
			//encontrar la raiz en el intervalo dado
			solucion sol = b.encontrar(xInf, xSup, tolerancia, n);
			//imprimir la solucion
			imprimir_solucion(sol);
			cout <<"-------------------------------------------------------------------" << endl;
			
			cout <<"Solucion por el metodo de regla falsa" << endl;
			//crear la instancia del metodo
			regla_falsa rf(str_func);
			//encontrar la raiz en el intervalo dado
			solucion solRf = b.encontrar(xInf, xSup, tolerancia, n);
			//imprimir la solucion
			imprimir_solucion(solRf);
			cout <<"-------------------------------------------------------------------" << endl;
			
			cout <<"Solucion por el metodo de Newton Raphson" << endl;
			//crear la instancia del metodo
			double p0 =xInf;
			
			string str_dfunc = "~(e^(~x)) + 2*x";
			//crear la instancia del metodo
			newton_raphson nr(str_func, str_dfunc);
			
			solucion solNr = nr.encontrar(p0, tolerancia, n);
			
			imprimir_solucion(solNr);
			cout <<"-------------------------------------------------------------------" << endl;
			
			double x0= xInf;//extremo inferior
			double x1 = xSup;//extremo superior del intervalo
			
			cout<< "Intervalo: " << x0 << "....." << x1 << endl;
			
			cout <<"Solucion por el metodo secante" << endl;
			//crear la instancia del metodo
			secante sec(str_func);
			//encontrar la raiz en el intervalo dado
			solucion solSec = sec.encontrar(x0, x1, tolerancia, n);
			//imprimir la solucion
			imprimir_solucion(solSec);
			
			cout <<"-------------------------------------------------------------------" << endl;
	}
	void caso_4() {			
		string str_func = "(e^~(x^2)) - x";
		double x0= 0.5f;//extremo inferior
		double x1 = 2.0f;//extremo superior del intervalo
		
		
		double tolerancia = 1.0f;//error relativo porcentual
		int n = 100;
		
		
		cout<<"Funcion: " <<str_func << endl;
		cout<< "Intervalo: " << x0 << "....." << x1 << endl;
		
		cout <<"Solucion por el metodo secante" << endl;
		//crear la instancia del metodo
		secante sec(str_func);
		//encontrar la raiz en el intervalo dado
		solucion sol = sec.encontrar(x0, x1, tolerancia, n);
		//imprimir la solucion
		imprimir_solucion(sol);
		
		cout <<"-------------------------------------------------------------------" << endl;
		}
	void caso_5() {			
		string str_func = "2*(e^(~x)) - sin (x)";
		double x0= 1.2f;//extremo inferior
		double x1 = 2.0f;//extremo superior del intervalo
		
		
		double tolerancia = 1.0f;//error relativo porcentual
		int n = 100;
		
		
		cout<<"Funcion: " <<str_func << endl;
		cout<< "Intervalo: " << x0 << "....." << x1 << endl;
		
		cout <<"Solucion por el metodo secante" << endl;
		//crear la instancia del metodo
		secante sec(str_func);
		//encontrar la raiz en el intervalo dado
		solucion sol = sec.encontrar(x0, x1, tolerancia, n);
		//imprimir la solucion
		imprimir_solucion(sol);
		
		cout <<"-------------------------------------------------------------------" << endl;
	}
	void caso_6(){
		
		string str_func = "x^3 - (5*(x^2)) + (7*x) - 3";
		
		cout <<"Solucion por el metodo de Newton Raphson G" << endl;
		//crear la instancia del metodo
		double p0 =1.0f;
		double tolerancia = 1.0f;
		int n = 100;
		
		string str_dfunc = "3*x^2 - 10*x + 7";
		string str_d2func = "6*x -10";
		//crear la instancia del metodo
		newton_raphson_g nrg(str_func, str_dfunc, str_d2func);
		
		solucion solNrg = nrg.encontrar(p0, tolerancia, n);
		
		imprimir_solucion(solNrg);
		
		cout <<"-------------------------------------------------------------------" << endl;
	}
	
	
