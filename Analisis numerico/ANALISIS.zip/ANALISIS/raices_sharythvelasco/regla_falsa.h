/**
*/
#ifndef REGLA_FALSA_H
#define REGLA_FALSA_H
#include<cmath>
#include<iostream>
#include<string.h>
#include "expression.h"
#include "raices.h"

using std:: string;
using std:: cout;
using std:: endl;


using raices::aproximacion;
using raices::solucion;
namespace raices{
	/**
	* @brief Metodo de la regla falsa
	* @param str_func Texto de la funcion
	*/
	
	class regla_falsa{
		
	public:
		/**
		* @brief Crea una nueva instancia de regla falsa
		* @param xi valor interior del intervalo
		* @param xs valor superior del intervalo
		* @param tolerancia  (error relativo porcentual)
		* @param n Maximo numero de iteraciones
		* @return Raiz encontrada || NAN
		*/
		regla_falsa(string str_func):f(str_func) {
		}
		
		solucion encontrar(double xi, 
						   double xs, 
						   double tolerancia,
						   int n){
			//Solucion a retornar
			solucion sol;
			
			if (es_raiz(f, xi)) {
				sol.raiz = xi;
				return sol;
			}
			if (es_raiz(f, xs)) {
				sol.raiz = xs;
				return sol;
			}
			
			//verificar que se cumpla TVI
			if ( f(xi) * f(xs) > 0) {
				return sol;
			}
			
			//paso 1
			int i =1;
			//paso 2: calcular la primera aproximacion y evaluar en cual sub intervalo se cumple el teorema de valor intermedio 
			double xrAnt = xs - ((f(xs)*(xi - xs))/(f(xi)-f(xs)));
			if(f(xi) * f(xrAnt)>0.0f){
				xi = xrAnt;
			}else {
				xs = xrAnt;
			}
			//paso 3
			while (i<=n){
				//paso 4: calculo de la nueva raiz y el error relativo
				double xrNueva = xs - ((f(xs)*(xi - xs))/(f(xi)-f(xs)));
				
				//crea una instancia de aproximacion
				aproximacion ap(xrAnt, xrNueva);
				
				//				//adicionar la nueva aproximacion del vector de solucion
				sol.agregar(ap);
				
				
				//paso 5
				if (fabs(f(xrNueva)) < DBL_EPSILON || ap.erp < tolerancia){
					//solucion encontrada, guardar la raiz y retornar
					sol.raiz = xrNueva;
					return sol;
				}
				//paso 6
				i++;
				
				//paso 7: redefinir el intervalo 
				if(f(xi) * f(xrNueva)>0.0f){
					xi = xrNueva;
				}else {
					xs = xrNueva;
				}
				
				xrAnt = xrNueva;
				
			}
			return sol;
		}
	private:
				expression f; /* Evaluador de la funcion */
	};
};

#endif
