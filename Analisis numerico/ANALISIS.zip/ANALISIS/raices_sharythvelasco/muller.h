/**
*@file
*@brief Metodo de Newton Raphson Generalizado
*@author Sharyth Velasco <sharythvelasco@unicauca.edu.co>
**/
#ifndef MULLER_H
#define MULLER_H

#include <cmath>
#include <string>
#include "expression.h"
#include "raices.h"

using std::string;
using std::cout;
using raices::aproximacion;
using raices::solucion;

namespace raices {
	class muller {
	public:
		muller(string str_func):f(str_func) {
			
		}
		
		solucion encontrar(
						   double x0,
						   double x1,
						   double x2,
						   double tolerancia,
						   int n) {
			solucion sol;
			//paso 1
			double h1 = x1 -x0;
			double h2 = x2- x1;
			double d1 = ((f(x1)-f(x0))/h1);
			double d2 = ((f(x2)-f(x1))/h2);
			double a = ((d2 - d1)/(h2 + h1));
			int i = 2;
			
			//paso 2
			while (i<=n) {
				//paso 3
				double b = d2 + (h2 * a);
				double c = f(x2);
				double D = sqrt(pow(b, 2) - (4.0f * a * c));
				
				//paso 4
				double E = b - D;
				if (fabs(b-D)< fabs(b+D)) {
					E = b+D;
				}
				//paso 5 
				double h = (-2.0f * c)/E;
				double p = x2 + h;
				//paso 6
				aproximacion ap(x2, p);
				sol.agregar(ap);
				if (ap.erp < tolerancia) {
					sol.establecer(p);
					return sol;
				}
				//paso 7 
				x0 = x1;
				x1=x2;
				x2=p;
				
				h1 = x1 -x0;
				h2 = x2- x1;
				d1 = ((f(x1)-f(x0))/h1);
				d2 = ((f(x2)-f(x1))/h2);
				a = ((d2 - d1)/(h2 + h1));
				i++;
				
			}
			
			return sol;
		}
	
	private:
			expression f;					
	};
};


#endif
