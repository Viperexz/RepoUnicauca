/**
*@file
*@brief Metodo de Newton Raphson Generalizado
*@author Sharyth Velasco <sharythvelasco@unicauca.edu.co>
**/

#ifndef NEWTON_RAPHSON_G_H
#define NEWTON_RAPHSON_G_H

#include "expression.h"
#include "raices.h"

using std:: string;
using raices:: es_raiz;
using raices:: aproximacion;
using raices:: solucion;

namespace raices {
	/**
	*@brief M�todo de Newton Raphson Generalizado
	**/
	
	class newton_raphson_g {
	public:
		/**
		*@brief Crea una nueva instancia Newton Raphson Generalizado
		*@param str_func Texto de funci�n
		*@param str_dfunc Texto de la derivada
		*@param str_d2func Texto de la segunda derivada
		**/
		newton_raphson_g(string str_func,
						 string str_dfunc,
						 string str_d2func):f(str_func),
									df(str_dfunc),
									d2f(str_d2func){
		}
		/**
		*@brief Encuentra la raiz mediante Newton Raphson Generalizado
		*@param p0 aproximacion inicial
		*@param tol Tolerancia
		*@param n M�ximo n�mero de iteraciones
		*@return Solucion Encontrada
		**/
			solucion encontrar(double p0, double tolerancia, int n) {
				solucion sol;
				
				//Verificar los extremos del intervalo
				if (es_raiz(f, p0)) {
					sol.raiz = p0;
					return sol;
				}
				
				//paso 1
				int i = 1;
				
				//paso 2
				while (i<= n) {
					//paso 3
					double p = p0 - ((f(p0) * df(p0)) / 
									(pow(df(p0),2) -
									 (f(p0) * d2f(p0))));
					//Crear instancia de aproximacion
					aproximacion ap(p0, p);
					sol.agregar(ap);
					
					//paso 4
					if (ap.erp < tolerancia) {
						sol.raiz = p;
						return sol;
						
					}
					//paso 5
					i++;
					
					//paso 6
					p0 =p;
					
				}
				return sol;
			}
		
	private:
		expression f; //Funci�n a evaluar 
		expression df; //Derivada de la funci�n a evaluar
		expression d2f; //Segunda derivada de la funci�n a evaluar
	};
};

#endif
