/**
* @file
* @brief Metodo de biseccion
* @author Sharyth Velasco sharythvelasco@unicauca.edu.co
*/
#ifndef BISECCION_H
#define BISECCION_H
#include<cmath>
#include<string.h>
#include "expression.h"
#include<iostream>
#include "raices.h"


using std:: string;
using std:: cout;
using std:: endl;

using raices:: es_raiz;
using raices:: aproximacion;
using raices:: solucion;
namespace raices{
	/**
	* @brief Metodo de biseccion
	* @param str_func Texto de la funcion
	*/
	
	class biseccion{
		
	public:
		/**
		* @brief Crea una nueva instancia de biseccion
		* @param xa valor interior del intervalo
		* @param xb valor superior del intervalo
		* @param tolerancia  (error relativo porcentual)
		* @param n Maximo numero de iteraciones
		* @return Raiz encontrada || NAN
		*/
		biseccion(string str_func): f(str_func) {
		}
		
		solucion encontrar(double xa, 
						 double xb, 
						 double tolerancia,
						 int n){
			//Solucion a retornar
			solucion sol;
			
			if (es_raiz(f, xa)) {
				sol.raiz = xa;
				return sol;
			}
			if (es_raiz(f, xb)) {
				sol.raiz = xb;
				return sol;
			}
			
			//verificar que se cumpla TVI
			if ( f(xa) * f(xb) > 0) {
				return sol;
			}
						
			//paso 1
			int i =1;
			//paso 2: calcular punto medio y evaluar en cual sub intervalo se cumple el teorema de valor intermedio 
			double xAnt = (xa + xb)/2.0f;
			if(f(xa) * f(xAnt)>0.0f){
				xa = xAnt;
			}else {
				xb = xAnt;
			}
			//paso 3
			while (i<=n){
				//paso 4: calculo de la nueva raiz y el valor relativo
				double xNueva = (xa + xb)/2.0f;
				
				//crea una instancia de aproximacion
				aproximacion ap(xAnt, xNueva);
					
//				//adicionar la nueva aproximacion del vector de solucion
				sol.agregar(ap);
			
				
				//paso 5
				if (es_raiz(f, xNueva) || ap.erp < tolerancia){
					//solucion encontrada, guardar la raiz y retornar
					sol.raiz = xNueva;
					return sol;
				};
				
				//paso 6
				i++;
			
				//paso 7: redefinir el intervalo 
				if(f(xa) * f(xNueva)>0.0f){
					xa = xNueva;
				}else {
					xb = xNueva;
				};
				
				xAnt = xNueva;
				
			};
			return sol;
		};
	private:
		expression f; /* Evaluador de la funcion */
	};
}
#endif
