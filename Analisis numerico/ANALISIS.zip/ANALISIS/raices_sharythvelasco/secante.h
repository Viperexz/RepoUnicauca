/**
*@file
*@brief Declaraciones del m�todo de la Secante
*@author Sharyth Velasco <sharythvelasco@unicauca.edu.co>
**/
#ifndef SECANTE_H
#define SECANTE_H

#include <string>
#include "raices.h"

using std::string;
using raices::solucion;
using raices::aproximacion;

namespace raices {
	/**
	*@brief Metodo de la secante 
	*/
	class secante {
	public:
		/**
		*@brief Crea una nueva instancia de Secante
		*@param str_func Texto de funci�n
		**/
		secante (string str_func):f(str_func) {
		
	}
		/**
		*@brief Encuentra la raiz con los par�metros dados
		*@param x0 valor inferior
		*@param x1 valor superior
		*@param tol tolerancia (error relativo porcentual)
		*@param n maximo numero de iteraciones
		*@return solucion del metodo
		**/
	solucion encontrar(
			double x0,
			double x1,
			double tolerancia,
			int n) {
		solucion sol;
		//Verificar los extremos del intervalo
		if (es_raiz(f, x0)) {
			sol.raiz = x0;
			return sol;
		}
		if (es_raiz(f, x1)) {
			sol.raiz = x1;
			return sol;
		}
		//Paso 1
		int i = 1;
		
		do {
			//calcular la nueva aproximacion
			double x2 = x1-(( f(x1)*(x0 - x1))/( f(x0)-f(x1) ));
			//crear la instancia de la aproximacion
			aproximacion aprox(x1, x2);
			//adicionar la aprox de la solucion
			sol.agregar(aprox);
			//verificar si se encontro la raiz
			if (aprox.erp < tolerancia){
				sol.raiz = x2;
				return sol;
			}
			//Sigue iteraci�n
			i++;
			
			//Actualizar los valores x0 y x1
			x0 = x1;
			x1 = x2;
		}
		while (i <= n );
		//Retornar la soluci�n
		return sol;
	}
	private:
	expression f; //Evaluador de la funci�n
};
}

#endif
