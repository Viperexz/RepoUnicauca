#include "casos.h"
#include <iostream>
#include <string>
#include "biseccion.h"
#include "expression.h"
#include "raices.h"
#include "newton_raphson.h"
#include "regla_falsa.h"
#include "casos.h"
#include "secante.h"
#include "newton_raphson_g.h"
#include "muller.h"

using std:: cout;
using std:: endl;
using std:: string;

using raices::muller;
using raices:: newton_raphson_g;
using raices:: secante;
using raices:: newton_raphson;
using raices:: biseccion;
using raices:: regla_falsa;
using raices:: aproximacion;
using raices:: solucion; 
using raices:: imprimir_solucion;

#define tolerancia 1e-7f
	void caso_1_Newton() {			
		string str_func = "12.2*(1-e^(~0.04*x))+5.5*(e^(~0.04*x))-10.736";
		double xInf= 38.0f;//extremo inferior
		double xSup = 39.25f;//extremo superior del intervalo
	
		int n = 100;
	
		cout <<"Solucion por el metodo de Newton Raphson" << endl;
		//crear la instancia del metodo
		double p0 =xInf;
	
		string str_dfunc =  "0.268*e^~(0.04x)";
		//crear la instancia del metodo
		newton_raphson nr(str_func, str_dfunc);
	
		solucion solNr = nr.encontrar(p0, tolerancia, n);
	
		imprimir_solucion(solNr);
		cout <<"*********************************************************************" << endl;
	
	}

	void caso_1_Secante() {
		string str_func = "12.2*(1-e^(~0.04*x))+5.5*(e^(~0.04*x))-10.736";
		double x0= 10.88f;//extremo inferior
		double x1 = 40.9f;//extremo superior del intervalo
		
		int n = 100;	
	
		cout<<"Funcion: " <<str_func << endl;
		cout<< "Intervalo: " << x0 << "....." << x1 << endl;
	
		cout <<"Solucion por el metodo secante" << endl;
		//crear la instancia del metodo
		secante sec(str_func);
		//encontrar la raiz en el intervalo dado
		solucion sol = sec.encontrar(x0, x1, tolerancia, n);
		//imprimir la solucion
		imprimir_solucion(sol);
	
		cout <<"*********************************************************************" << endl;
	}

	void caso_1_ReglaFalsa(){
		string str_func = "12.2*(1-e^(~0.04*x))+5.5*(e^(~0.04*x))-10.736";
		double xInf= 20.25f;//extremo inferior
		double xSup = 38.25f;//extremo superior del intervalo
		
		int n = 100;
		regla_falsa b(str_func);
	
		cout<<"Funcion: " <<str_func << endl;
		cout<< "Intervalo: " << xInf << "....." << xSup << endl;
	
		cout <<"Solucion por el metodo de regla falsa" << endl;
		//crear la instancia del metodo
		regla_falsa rf(str_func);
		//encontrar la raiz en el intervalo dado
		solucion solRf = b.encontrar(xInf, xSup, tolerancia, n);
		//imprimir la solucion
		imprimir_solucion(solRf);
		cout <<"*********************************************************************" << endl;
	}

	void caso_2_Generalizado() {
			solucion solNrg;
			double p0;
			//double tolerancia = 1e-7f;
			int n = 100;
			
			string str_func = "0.0074*x^(4)-0.28*x^(3)+3.385*x^(2)-11.9*x+5";
			string str_dfunc = "0.0296*x^3-0.84*x^2+6.77*x-11.9";
			string str_d2func = "0.0888*x^2-1.68*x+6.77";
			
			p0 = 0.0f;
			cout <<"*********************************************************************" << endl;
			cout<<"Funcion: " <<str_func << endl;
			cout <<"Solucion por el metodo de Newton Raphson Generalizado: " << endl;
			cout << "Punto inicial: " << p0 << endl;
			cout <<"Tolerancia: " <<tolerancia<<endl;
			
			//crear la instancia del metodo
			newton_raphson_g nrg(str_func, str_dfunc, str_d2func);
			
			solNrg = nrg.encontrar(p0, tolerancia, n);
			
			imprimir_solucion(solNrg);
			cout <<"-------------------------------------------------------------------" << endl;
			
			p0 = 4.0f;
			cout << "Punto inicial: " << p0 << endl;
			cout<<"Tolerancia: "<<tolerancia<<endl;
			
			solNrg = nrg.encontrar(p0, tolerancia, n);
			
			//Imprimir la solucion para el metodo de regla falsa
			imprimir_solucion(solNrg);
			
			cout <<"" << endl;
			
	}
	void caso_2_Newton(){
		int n = 200;
		double p0;
		//double tolerancia = 1e-7f;//error relativo porcentual
		solucion solNr;
		
		string str_func = "0.0074*x^(4)-0.28*x^(3)+3.385*x^(2)-11.9*x+5";
		string str_dfunc = "0.0296*x^3-0.84*x^2+6.77*x-11.9";
		
		cout <<"*********************************************************************" << endl;
		cout <<"*********************************************************************" << endl;
		cout<<"Funcion: " <<str_func << endl;
		cout <<"Solucion por el metodo de Newton Raphson: " << endl;
		cout << "Punto inicial: " << p0 << endl;
		cout <<"Tolerancia: " <<tolerancia<<endl;
		
		p0 = 0.0f;
		
		//crear la instancia del metodo
		newton_raphson nr(str_func, str_dfunc);
		
		solNr = nr.encontrar(p0, tolerancia, n);
		
		imprimir_solucion(solNr);
		
		cout <<"-------------------------------------------------------------------" << endl;
		cout <<"Solucion por el metodo de Newton Raphson: " << endl;
		cout << "Punto inicial: " << p0 << endl;
		cout <<"Tolerancia: " <<tolerancia<<endl;
		//crear la instancia del metodo
		p0 = 4.0f;
		
		solNr = nr.encontrar(p0, tolerancia, n);
		
		imprimir_solucion(solNr);
		cout <<"" << endl;
		
	}
	void caso_2_Muller() {
		string str_func = "0.0074*x^(4)-0.28*x^(3)+3.385*x^(2)-11.9*x+5";
		double xInf= 1.0f;//extremo inferior
		double xSup = 5.0f;//extremo superior del intervalo
		double x0= 0.5f;// puntos de la parabola
		double x1 = 2.0f;//puntos de la parabola
		double x2 = 4.0f;//puntos de la parabola
	
		//double tolerancia = 1e-7;//error relativo porcentual
		int n = 100;
		
		cout <<"*********************************************************************" << endl;
		cout <<"*********************************************************************" << endl;
		cout<<"Funcion: " <<str_func << endl;
		cout<< "Intervalo: " << xInf << "....." << xSup << endl;
		cout <<"Solucion por el metodo de Muller: " << endl;
		
		cout <<"Puntos de la parabola: " 
			<< x0 << " , "
			<<x1 << ", " << x2 << endl;
		
		//crear la instancia del metodo
		muller mul(str_func);
		//encontrar la raiz en el intervalo dado
		solucion solMuller = mul.encontrar(x0, x1, x2, tolerancia, n);
		//imprimir la solucion
		imprimir_solucion(solMuller);
		
		cout <<"-------------------------------------------------------------------" << endl;
	}
	
