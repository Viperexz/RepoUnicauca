#include<iostream>
#include<string>
#include "casos.h"

using std:: cin;
using std:: cout;
using std:: endl;
using std:: string;


int main () {
	char opc2 = 'n';
	do{
		system("cls");
		cout << "Implementacion de metodos numericos para calcular la raiz de una funcion" << endl;
		cout << " " << endl;
		cout << "CASO 1: 12.2*(1-e^(~0.04*x))+5.5*(e^(~0.04*x))-10.736" << endl;
		cout << " " << endl;
		cout << "1. Metodo de Newton Raphson para caso 1" << endl;
		cout << "2. Metodo de Secante para caso 1." << endl;
		cout << "3. Metodo de Regla falsa para caso 1." << endl;
		cout << " " << endl;
		cout << "CASO 2: 0.0074*x^(4) - (0.28*x^(3)) + (3.385*x^(2)) - (11.9*x) +5" << endl;
		cout << " " << endl;
		cout << "4. Metodo de Newton Raphson Generalizado para caso 2." << endl;
		cout << "5. Metodo de Newton Raphson para caso 2." << endl;
		cout << "6. Metodo de Muller para caso 2." << endl;
		cout << " " << endl;
		cout << "Seleccione una de las anteriores opciones: ";
		int opc1;
		cin >> opc1;
		switch(opc1){
		case 1:
			caso_1_Newton();
			break;
		case 2:
			caso_1_Secante();
			break;
		case 3:
			caso_1_ReglaFalsa();
			break;
		case 4:
			caso_2_Generalizado();
			break;
		case 5:
			caso_2_Newton();
			break;
		case 6:
			caso_2_Muller();
			break;
		default:
			cout << "Recuerde seleccionar una de las opciones mostradas..." << endl;
			system("pause");
			system("cls");
			break;
		}
		cout << "Volver al menu principal (s/n): ";
		cin >> opc2;
	}while(opc2 == 's');
}

