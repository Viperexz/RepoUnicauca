#ifndef CASOS_H
#define CASOS_H

/**
*@brief Caso 1.  12.2*(1-e^(~0.04*x))+5.5*(e^(~0.04*x))-10.736 :
por Newton Raphson
**/
void caso_1_Newton();
/**
*@brief Caso 1. 12.2*(1-e^(~0.04*x))+5.5*(e^(~0.04*x))-10.736 :
por Secante
**/
void caso_1_Secante();
/**
*@brief Caso 1. 12.2*(1-e^(~0.04*x))+5.5*(e^(~0.04*x))-10.736 :
por Regla falsa
**/
void caso_1_ReglaFalsa();
/**
*@brief Caso 2. 0.0074*x^(4) - (0.28*x^(3)) + (3.385*x^(2)) - (11.9*x) +5 :
por Newton Raphson Generalizado
**/
void caso_2_Generalizado();
/**
*@brief Caso 2. 0.0074*x^(4) - (0.28*x^(3)) + (3.385*x^(2)) - (11.9*x) +5 :
por Newton Raphson 
**/
void caso_2_Newton();
/**
*@brief Caso 2. 0.0074*x^(4) - (0.28*x^(3)) + (3.385*x^(2)) - (11.9*x) +5 :
por Muller
**/
void caso_2_Muller();


#endif
