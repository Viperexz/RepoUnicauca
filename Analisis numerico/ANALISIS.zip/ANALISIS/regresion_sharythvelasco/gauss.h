
/**
 * @file
 * @brief M�todo de Elminiaci�n de Gauss
 * @author Sharyth Velasco D�az <sharythvelasco@unicauca.edu.co> 
 * @copyright MIT License
*/

#ifndef GAUSS_H
#define GAUSS_H

#include <vector>

using std::vector;

/**
 * @brief Eliminacion de Gauss
 * @param m Matriz de sistema de ecuaciones
 * @return Vector solucion
 * @note Esta funcion modifica la matriz de entrada.
*/

vector<double> gauss(vector<vector<double>> &m); 



#endif
