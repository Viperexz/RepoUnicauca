
/**
 * @file 
 * @brief Regresion
 * @author Sharyth Velasco Diaz <sharythvelasco@unicauca.edu.co>
 * @copyright MIT License
*/

#ifndef REGRESION_H
#define REGRESION_H

#include <algorithm>
#include <vector>
#include <cmath>
#include <iostream>
#include <iomanip>

using std::cout;
using std::endl;

using std::vector;
/**
 * @brief M�todos de regresi�n
*/
namespace regresion {
	
	/**
	 * @brief Modelos de regresion lineal
	 * Recta de regresion lineal de la forma y = b1*x + b0
	*/
	
	struct modelo_lineal {
		
		double b0 = NAN; /*!< Termino independiente*/
		double b1 = NAN; /*!< Coeficiente de x*/
		double s_t = 0.0f; /*!< Sumatoria de la diferencia cuadr�tica entre y e y promedio*/
		double s_y = NAN; /*!< Desviaci�n estandar y*/
		double sr = 0.0f; /*!< Discrepancia entre el valor real y el valor estimado*/
		double syx = NAN; /*!< Error est�ndar de aproximaci�n*/
		double r2 = 0.0f; /*!< Coeficiente de determinaci�n*/
		
		/**
		 * @brief Imprime el modelo por la salida est�ndar
		*/
		void imprimir () {
			
			cout 
				<< "y - " 
				 << b1 
				<< " + x"
				<<(b0<0?" - " : " + ")
				<< fabs(b0)
				<< endl;
			cout <<"Desviaci�n est�ndar : " << s_y << endl;
			cout <<"Error est�ndar de aproximaci�n: " << syx << endl;
			cout <<"Coeficiente de determinaci�n r2: " << r2 << endl;
				
		}
		
		/**
		* @brief Calcula el valor de y estimado para un x dado
		* @param p_x Valor de x a estimar
		* @return Valor de y estimado 
		*/
		
		double estimar (double p_x) {
			return ((b1 * p_x) + b0);
		}
		
		
		
	};
	/**
	 * @brief Modelo linealizado mediante funcion potencia
	*/
	
	struct modelo_potencia {
		modelo_lineal lineal; /*! <Modelo de los datos linealizados*/
		double a; /*! <Potencia de x*/
		double c; /*! <Coeficiente de x*/
		
		/**
		* @brief Calcula el valor de y estimado para un x dado
		* @param p_x Valor de x a estimar
		* @return Valor de y estimado 
		*/
		double estimar (double p_x) {
			return c * pow(p_x,a);
		}
		
		/**
		* @brief Imprime el modelo por la salida est�ndar
		*/
		void imprimir () {
			
			cout 
				<< "y = " 
				<< c 
				<< " * x ^"
				<<a
				<< endl;
			cout <<"Desviaci�n est�ndar : " << lineal.s_y << endl;
			cout <<"Error est�ndar de aproximaci�n: " << lineal.syx << endl;
			cout <<"Coeficiente de determinaci�n r2: " << lineal.r2 << endl;
			
		}
		
	};
	
	/**
	* @brief Modelo linealizado mediante funcion exponencial
	*/
	struct modelo_exponencial {
		modelo_lineal lineal; /*! <Modelo de los datos linealizados*/
		double a; /*! <Potencia de e*/
		double c; /*! <Coeficiente de e^(a*x)*/
		
		/**
		* @brief Calcula el valor de y estimado para un x dado
		* @param p_x Valor de x a estimar
		* @return Valor de y estimado 
		*/
		double estimar (double p_x) {
			return c * exp(a*p_x);
		}
		
		/**
		* @brief Imprime el modelo por la salida est�ndar
		*/
		void imprimir () {
			
			cout 
				<< "y = " 
				<< c 
				<< " * e ^("
				<< a
				<<"* x)"
				<< endl;
			cout <<"Desviaci�n est�ndar : " << lineal.s_y << endl;
			cout <<"Error est�ndar de aproximaci�n: " << lineal.syx << endl;
			cout <<"Coeficiente de determinaci�n r2: " << lineal.r2 << endl;
			
		}
		
	};
	
	
	/**
	* @brief Regresion simple
	*/
	
	class lineal_simple {
		
		/**
		 * @brief Crea una instancia de regresion lineal simple
		 * @param v_x Valores de la variable independiente
		 * @param v_y Valores de la variable dependiente
		*/
	public:
		
		lineal_simple(vector<double> v_x, vector <double> v_y) : x(v_x), y(v_y) {
			calcular_modelo();
		}
		
		
		

		/**
		* @brief Calcula el valor de y estimado para un x dado
		* @param p_x Valor de x a estimar
		* @return Valor de y estimado 
		*/
		double estimar (double p_x) {
			size_t n = x.size();
			//Verificar que la x se encuentre en el intervalo
			if(n==0 || p_x < x[0] || p_x > x[n-1]) {
				return NAN;
			}
			return modelo.estimar(p_x);
		}
		
		modelo_lineal obtener_modelo() {
			return modelo;
		}
		
	private:
		vector<double> x; /*!< Variable independiente*/
		vector<double> y; /*!< Variable dependiente*/
		modelo_lineal modelo;
		
		/**
		 * @brief Calcula del modelo de regresion lineal
		*/
		void calcular_modelo() {
			//Obtener la cantidad de datos suficientes
			//Se necesitan al menos dos datos para calcular sy
			//Se necesitan al menos tres datos para calcular syx
			size_t n= x.size();
			if (n<3) {return;}
			
			//Validar que x e y tengan la misma cantidad de datos.
			if(n != y.size()) {return;}
			
			
			
			double 
				s_x= 0.0f, 
				s_y = 0.0f, 
				s_xy= 0.0f, 
				s_x2= 0.0f;
			
			for (size_t i = 0; i<n ; i++){
				s_x += x[i];
				s_y += y[i];
				s_xy += x[i] * y[i];
				s_x2 += x[i] * x[i];
			}
			
			double x_prom = s_x / (double) n;
			double y_prom = s_y / (double) n;
			
			modelo.b1 = (s_xy - (y_prom * s_x))
						/
						(s_x2 - (x_prom * s_x));
			
			modelo.b0 = y_prom - (modelo.b1 * x_prom);
			
			//Calcular par�metros de calidad
			
			for ( size_t i = 0; i < n ; i ++ ) {
				modelo.s_t += pow(y[i] - y_prom,2);
				modelo.sr += pow(y[i] - modelo.estimar(x[i]),2);
			}
			//Calcular la desviaci�n est�ndar
			modelo.s_y = sqrt(modelo.s_t/(double) (n - 1)); 
			//Calcular el error est�ndar de aproximaci�n 
			modelo.syx = sqrt(modelo.sr/(double) (n - 2));
			
			//Calcular coeficiente de determinaci�n
			modelo.r2 = (modelo.s_t - modelo.sr) / modelo.s_t;
			
			
		}
		
	};
	/**
	 * @brief Regresion mediante funcion potencia
	*/
	class potencia {
	public:
		
		/**
		* @brief Crea una instancia de regresion linealizada con funcion potencia
		* @param v_x Valores de la variable independiente
		* @param v_y Valores de la variable dependiente
		*/
		potencia(vector<double> v_x, vector<double> v_y): x(v_x), y(v_y) {
			
			calcular_modelo();
		}
		
		/**
		* @brief Calcula el valor de y estimado para un x dado
		* @param p_x Valor de x a estimar
		* @return Valor de y estimado 
		*/
		double estimar (double p_x) {
			size_t n = x.size();
			//Verificar que la x se encuentre en el intervalo
			if(n==0 || p_x < x[0] || p_x > x[n-1]) {
				return NAN;
			}
			return modelo.estimar(p_x);
		}
		
		modelo_potencia obtener_modelo() {
			return modelo;
		}
		
	private:
		
		vector <double> x; /*!< Variable independiente*/
		vector <double> y; /*!< Variable dependiente*/
		modelo_potencia modelo; /*!< Modelo*/
		
		/**
		* @brief Calcula del modelo de regresion lineal
		*/
		void calcular_modelo() {
			//1. Transfomar x = log(x)
			
			vector<double> X(x);
				
			std::for_each(X.begin(), X.end(),
						  [](double & val) {val = log10(val);}
						  );
			
			//2. Transfomar y = log(y)
			
			vector<double> Y(y);
			
			std::for_each(Y.begin(), Y.end(),
						  [](double & val) {val = log10(val);}
						  );
			
			//3. Crear una instancia de regresion lineal simple
			
			
			
			//   Pas�ndole los datos transformados
			
			lineal_simple reg_lineal(X,Y);
			
			
			//4. Obtener el modelo de regresi�n lineal simple
			
			modelo.lineal = reg_lineal.obtener_modelo();
			
			//5. Con base en el modelo obtenido, calcular "c" y "a"
			
			modelo.c = pow(10.0f, modelo.lineal.b0);
			modelo.a = modelo.lineal.b1;
			
			
		}
	};
	
	/**
	* @brief Regresion mediante funcion exponencial
	*/
	class exponencial {
	public:
		
		/**
		* @brief Crea una instancia de regresion linealizada con funcion potencia
		* @param v_x Valores de la variable independiente
		* @param v_y Valores de la variable dependiente
		*/
		exponencial(vector<double> v_x, vector<double> v_y): x(v_x), y(v_y) {
			
			calcular_modelo();
		}
		
		/**
		* @brief Calcula el valor de y estimado para un x dado
		* @param p_x Valor de x a estimar
		* @return Valor de y estimado 
		*/
		double estimar (double p_x) {
			size_t n = x.size();
			//Verificar que la x se encuentre en el intervalo
			if(n==0 || p_x < x[0] || p_x > x[n-1]) {
				return NAN;
			}
			return modelo.estimar(p_x);
		}
		
		modelo_exponencial obtener_modelo() {
			return modelo;
		}
		
	private:
			
			vector <double> x; /*!< Variable independiente*/
			vector <double> y; /*!< Variable dependiente*/
			modelo_exponencial modelo; /*!< Modelo*/
			
			/**
			* @brief Calcula del modelo de regresion lineal
			*/
			void calcular_modelo() {
				//1. No se transforma
				
				vector<double> X(x);
				
				//2. Transfomar y = ln(y)
				
				vector<double> Y(y);
				
				std::for_each(Y.begin(), Y.end(),
							  [](double & val) {val = log(val);}
							  );
				
				//3. Crear una instancia de regresion lineal simple
				//   Pas�ndole los datos transformados
				
				lineal_simple reg_lineal(X,Y);
				
				
				//4. Obtener el modelo de regresi�n lineal simple
				
				modelo.lineal = reg_lineal.obtener_modelo();
				
				//5. Con base en el modelo obtenido, calcular "c" y "a"
				
				modelo.c = exp(modelo.lineal.b0);
				modelo.a = modelo.lineal.b1;
				
				
			}
	};
	
};

#endif
